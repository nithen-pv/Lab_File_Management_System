-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Jan 03, 2021 at 06:47 AM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.4.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `project`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `username` varchar(33) NOT NULL,
  `password` varchar(33) NOT NULL,
  `status` varchar(22) NOT NULL,
  `id` int(22) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`username`, `password`, `status`, `id`) VALUES
('admin', 'admin123', '', 1);

-- --------------------------------------------------------

--
-- Table structure for table `Batch`
--

CREATE TABLE `Batch` (
  `id` int(11) NOT NULL,
  `batch_name` varchar(11) NOT NULL,
  `course` varchar(22) NOT NULL,
  `year` int(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `Batch`
--

INSERT INTO `Batch` (`id`, `batch_name`, `course`, `year`) VALUES
(1, 'S1 ', 'BCA', 2020),
(2, 'S2 ', 'BCA', 2020),
(3, 'S3 ', 'BCA', 2020),
(4, 'S4', ' BCA', 2020),
(5, 'S5 ', 'BCA', 2020),
(6, 'S6 ', 'BCA', 2020),
(7, 'S6', 'ELECTRONICS', 2020);

-- --------------------------------------------------------

--
-- Table structure for table `Comment`
--

CREATE TABLE `Comment` (
  `id` int(10) NOT NULL,
  `file_id` int(10) NOT NULL,
  `student_id` int(11) NOT NULL,
  `commentor_name` varchar(22) NOT NULL,
  `message` varchar(500) NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `Comment`
--

INSERT INTO `Comment` (`id`, `file_id`, `student_id`, `commentor_name`, `message`, `date`) VALUES
(7, 56, 34, 'Joseph Deril', 'Lorem, ipsum dolor sit amet consectetur adipisicing elit. Culpa assumenda sunt, consectetur dignissimos omnis esse animi cumque blanditiis expedita nihil necessitatibus voluptatem voluptas dolorum, magni ratione itaque totam quia aliquam?', '2020-12-31 06:20:52'),
(8, 58, 34, 'Joseph Deril', 'hello', '2020-12-31 06:42:34'),
(9, 83, 34, 'Joseph Deril', 'test Comment asgddsgfdfhfhfgfdgdfg', '2020-12-31 16:22:15'),
(10, 83, 34, 'Joseph Deril', 'test Comment asgddsgfdfhfhfgfdgdfg', '2020-12-31 16:25:03'),
(11, 83, 34, 'Joseph Deril', 'test Comment asgddsgfdfhfhfgfdgdfg', '2020-12-31 16:25:40'),
(12, 83, 34, 'Joseph Deril', 'test Comment asgddsgfdfhfhfgfdgdfg', '2020-12-31 16:26:24'),
(13, 82, 34, 'Joseph Deril', '\r\n\r\nLorem, ipsum dolor sit amet consectetur adipisicing elit. Culpa assumenda sunt, consectetur dignissimos omnis esse animi cumque blanditiis expedita nihil necessitatibus voluptatem voluptas dolorum, magni ratione itaque totam quia aliquam?', '2020-12-31 16:26:44'),
(14, 61, 34, 'Joseph Deril', '\r\n\r\nLorem, ipsum dolor sit amet consectetur adipisicing elit. Culpa assumenda sunt, consectetur dignissimos omnis esse animi cumque blanditiis expedita nihil necessitatibus voluptatem voluptas dolorum, magni ratione itaque totam quia aliquam?', '2020-12-31 16:27:27'),
(15, 61, 34, 'Joseph Deril', '\r\n\r\nLorem, ipsum dolor sit amet consectetur adipisicing elit. Culpa assumenda sunt, consectetur dignissimos omnis esse animi cumque blanditiis expedita nihil necessitatibus voluptatem voluptas dolorum, magni ratione itaque totam quia aliquam?', '2020-12-31 16:27:45'),
(16, 56, 34, 'Joseph Deril', 'hai', '2020-12-31 16:31:39'),
(17, 56, 34, 'Joseph Deril', 'Oooi', '2020-12-31 16:36:28'),
(18, 56, 34, '', 'teacher', '2020-12-31 17:43:43'),
(19, 56, 34, 'Deril', 'teacher', '2020-12-31 17:44:40'),
(20, 56, 34, 'Deril', 'qwerty', '2020-12-31 17:44:48'),
(21, 56, 34, 'Deril', 'qwerty', '2020-12-31 17:45:02'),
(22, 56, 34, 'Deril', 'test', '2020-12-31 17:48:43'),
(23, 56, 34, 'Deril', 'hello', '2020-12-31 17:50:48'),
(24, 56, 34, 'Deril', 'mdgmsdgfgfdgdfgd', '2020-12-31 17:52:58'),
(25, 56, 34, 'Joseph Deril', '', '2021-01-02 09:57:27'),
(26, 56, 34, 'Joseph Deril', '', '2021-01-02 10:01:19'),
(27, 74, 34, 'Joseph Deril', 'test ', '2021-01-02 10:05:32'),
(28, 72, 34, 'Joseph Deril', '', '2021-01-02 10:12:47'),
(29, 56, 34, 'Joseph Deril', '', '2021-01-02 10:15:15'),
(30, 60, 34, 'Joseph Deril', '', '2021-01-02 10:15:48');

-- --------------------------------------------------------

--
-- Table structure for table `Coordinators`
--

CREATE TABLE `Coordinators` (
  `id` int(11) NOT NULL,
  `Name` varchar(33) NOT NULL,
  `username` varchar(33) NOT NULL,
  `password` varchar(33) NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `Coordinators`
--

INSERT INTO `Coordinators` (`id`, `Name`, `username`, `password`, `batch`) VALUES
(1, 'Joseph Deril', 'deril', 'deril123', 6),
(5, 'Murugan', 'murugan', 'murugan123', 4);

-- --------------------------------------------------------

--
-- Table structure for table `files`
--

CREATE TABLE `files` (
  `id` int(22) NOT NULL,
  `student_id` int(11) NOT NULL,
  `filename` varchar(33) NOT NULL,
  `file_size` int(33) NOT NULL,
  `batch` int(11) NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `files`
--

INSERT INTO `files` (`id`, `student_id`, `filename`, `file_size`, `batch`, `date`) VALUES
(56, 34, 'Form Design.odt', 12385, 6, '2020-12-17 06:42:39'),
(59, 34, 'BITCOIN.odp', 329030, 6, '2020-12-17 06:43:21'),
(60, 34, 'BITCOIN.odp', 329030, 6, '2020-12-17 06:44:03'),
(61, 34, 'BITCOIN.odp', 329030, 6, '2020-12-17 07:03:35'),
(62, 34, 'BITCOIN.odp', 329030, 6, '2020-12-17 07:04:08'),
(63, 34, 'BITCOIN.odp', 329030, 6, '2020-12-17 07:04:55'),
(65, 34, 'sw_P068.doc', 118999, 6, '2020-12-17 07:06:29'),
(66, 34, 'sw_P068.doc', 118999, 6, '2020-12-17 07:08:45'),
(67, 34, 'sw_P068.doc', 118999, 6, '2020-12-17 07:09:35'),
(68, 34, 'sw_P068.doc', 118999, 6, '2020-12-17 07:20:07'),
(69, 34, 'sw_P068.doc', 118999, 6, '2020-12-17 07:22:56'),
(70, 34, 'sw_P068.doc', 118999, 6, '2020-12-17 07:23:52'),
(71, 34, 'sw_P068.doc', 118999, 6, '2020-12-17 07:24:17'),
(72, 34, 'sw_P068.doc', 118999, 6, '2020-12-17 07:25:55'),
(73, 34, 'sw_P068.doc', 118999, 6, '2020-12-17 07:26:39'),
(74, 34, 'BITCOIN.odp', 329030, 6, '2020-12-17 07:27:39'),
(76, 34, 'BITCOIN.odp', 329030, 6, '2020-12-17 07:30:07'),
(77, 34, 'BITCOIN.odp', 329030, 6, '2020-12-17 07:30:20'),
(79, 34, 'BITCOIN.odp', 329030, 6, '2020-12-17 07:30:45'),
(80, 34, 'BITCOIN.odp', 329030, 6, '2020-12-17 07:30:56'),
(81, 34, 'Shakespear.txt', 1272, 6, '2020-12-17 07:40:42'),
(82, 34, 'online home service.docx', 46030, 6, '2020-12-17 07:41:19'),
(86, 35, 'Cousera certificate link', 325, 6, '2020-12-17 12:42:44');

-- --------------------------------------------------------

--
-- Table structure for table `Student`
--

CREATE TABLE `Student` (
  `id` int(11) NOT NULL,
  `Student_Name` varchar(33) NOT NULL,
  `RollNo` int(11) NOT NULL,
  `Batch` int(33) NOT NULL,
  `Username` varchar(33) NOT NULL,
  `Password` varchar(33) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `Student`
--

INSERT INTO `Student` (`id`, `Student_Name`, `RollNo`, `Batch`, `Username`, `Password`) VALUES
(34, 'student', 1, 6, 'student', 'student123'),
(35, 'harsih', 2, 1, 'harish', 'harish123'),
(37, 'farook', 3, 1, 'farook', 'farook123'),
(39, 'fayez', 12, 1, 'fayez', 'sdfdsf'),
(40, 'ajmal', 3, 1, 'ajmal', 'ajmal123');

-- --------------------------------------------------------

--
-- Table structure for table `Teachers`
--

CREATE TABLE `Teachers` (
  `id` int(11) NOT NULL,
  `name` varchar(33) NOT NULL,
  `batch` int(11) NOT NULL,
  `username` varchar(33) NOT NULL,
  `password` varchar(33) NOT NULL,
  `start` int(11) NOT NULL,
  `stop` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `Teachers`
--

INSERT INTO `Teachers` (`id`, `name`, `batch`, `username`, `password`, `start`, `stop`) VALUES
(1, 'Deril', 6, 'deril', 'deril123', 1, 3),
(6, 'Jasir', 6, 'jasir', 'jasir123', 5, 12);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `Batch`
--
ALTER TABLE `Batch`
  ADD PRIMARY KEY (`id`),
  ADD KEY `batch_name` (`batch_name`);

--
-- Indexes for table `Comment`
--
ALTER TABLE `Comment`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `Coordinators`
--
ALTER TABLE `Coordinators`
  ADD PRIMARY KEY (`id`),
  ADD KEY `batch` (`batch`);

--
-- Indexes for table `files`
--
ALTER TABLE `files`
  ADD PRIMARY KEY (`id`),
  ADD KEY `student_id` (`student_id`,`batch`),
  ADD KEY `batch` (`batch`);

--
-- Indexes for table `Student`
--
ALTER TABLE `Student`
  ADD PRIMARY KEY (`id`),
  ADD KEY `Batch` (`Batch`);

--
-- Indexes for table `Teachers`
--
ALTER TABLE `Teachers`
  ADD PRIMARY KEY (`id`),
  ADD KEY `batch` (`batch`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(22) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `Batch`
--
ALTER TABLE `Batch`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `Comment`
--
ALTER TABLE `Comment`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT for table `Coordinators`
--
ALTER TABLE `Coordinators`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `files`
--
ALTER TABLE `files`
  MODIFY `id` int(22) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=88;

--
-- AUTO_INCREMENT for table `Student`
--
ALTER TABLE `Student`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=86;

--
-- AUTO_INCREMENT for table `Teachers`
--
ALTER TABLE `Teachers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `Coordinators`
--
ALTER TABLE `Coordinators`
  ADD CONSTRAINT `Coordinators_ibfk_1` FOREIGN KEY (`batch`) REFERENCES `Batch` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION;

--
-- Constraints for table `files`
--
ALTER TABLE `files`
  ADD CONSTRAINT `files_ibfk_1` FOREIGN KEY (`student_id`) REFERENCES `Student` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION,
  ADD CONSTRAINT `files_ibfk_2` FOREIGN KEY (`batch`) REFERENCES `Batch` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION;

--
-- Constraints for table `Student`
--
ALTER TABLE `Student`
  ADD CONSTRAINT `Student_ibfk_1` FOREIGN KEY (`Batch`) REFERENCES `Batch` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION;

--
-- Constraints for table `Teachers`
--
ALTER TABLE `Teachers`
  ADD CONSTRAINT `Teachers_ibfk_1` FOREIGN KEY (`batch`) REFERENCES `Batch` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
